#pragma once

#include "Event.h"

#include <vector>

std::vector<Event> parse_events(int argc, const char** argv);
